# SensorMonitor

### A simple sensor monitoring program for Tizen 4 wearable devices

This app runs in the background on a Tizen 4 wearable, and continuously records the PPG and Accelerometer data to a local SQLite database file.

It runs whenever the device is off the charger.

## Build prerequisites
1. This program must be built using Tizen Studio. Install Tizen Studio from here: https://developer.tizen.org/development/tizen-studio/download
2. Open the Package Manager (follow the instructions from the above site), and make sure that '4.0 Wearable' is installed under the 'Main SDK' tab, as well as 'Samsung Certificate Extension' and 'Samsung Wearable Extension' from the 'Extension SDK' tab.

## Build

This program must be built using Tizen Studio.

1. Create an appropriate Certificate Profile for your device using the Certificate Manager.
2. Import the SensorMonitor directory and right-click on the SensorMonitor node.
3. Select 'Build Project'.
4. Select 'Build Signed Package'

## Installation

Use the SDB tool included with Tizen Studio to install the package file you created in the Build step.

```
/path_to_tizen_studio/tools/sdb install /path_to_SensorMonitor/Debug/com.waracle.wearable.tizen.sensormonitor-[VERSION]-arm.tpk
```

## Contact

Waracle Ltd

- support@waracle.com

## License

This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license. For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt.