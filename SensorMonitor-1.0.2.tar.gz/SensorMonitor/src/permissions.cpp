/*
 * permissions.cpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#include <permissions.hpp>
#include <logger.hpp>

#include <efl_extension.h>
#include <privacy_privilege_manager.h>
#include <sensormonitor.hpp>

// Timer used to await our permissions being granted by the user
static Ecore_Timer *startup_timer;

//
// O/S privilege request/response
//
typedef void (*permission_response_callback)(const char *privilege, bool request_response);

typedef struct _PERMISSION_RESPONSE_BLOCK
{
	const char *privilege;
	bool granted;
} PERMISSION_RESPONSE_BLOCK;

//
// The permissions we require a run-time request for
//
static PERMISSION_RESPONSE_BLOCK required_permissions[] = {
		{ "http://tizen.org/privilege/healthinfo",              false },
		{ "http://tizen.org/privilege/mediastorage",            false },
		{ "http://tizen.org/privilege/display",                 false },
};

//
// Tizen permission request response callback
//
static void permission_request_response_cb(ppm_call_cause_e cause, ppm_request_result_e result, const char *privilege, void *user_data)
{
	Logger &logger = Logger::getInstance();

	if (cause == PRIVACY_PRIVILEGE_MANAGER_CALL_CAUSE_ERROR)
    {
		logger.log(Logger::Module::SYSTEM, "permission_request_response_cb() callback failure for privilege '%s': %d", privilege, (int) result);
        return;
    }

	PERMISSION_RESPONSE_BLOCK *response_block = (PERMISSION_RESPONSE_BLOCK *) user_data;

	bool granted = (result == PRIVACY_PRIVILEGE_MANAGER_REQUEST_RESULT_ALLOW_FOREVER);

	logger.log(Logger::Module::SYSTEM, "[service] Permission '%s': %s", privilege, granted ? "granted" : "denied");

   	response_block->granted = granted;
}

//
// Request a specific app permission
//
static void request_app_permission(PERMISSION_RESPONSE_BLOCK *response_block)
{
	Logger &logger = Logger::getInstance();
    ppm_check_result_e result;

    int ret = ppm_check_permission(response_block->privilege, &result);
    if (ret == PRIVACY_PRIVILEGE_MANAGER_ERROR_NONE)
    {
    	switch (result)
    	{
    	case PRIVACY_PRIVILEGE_MANAGER_CHECK_RESULT_ALLOW:
    		permission_request_response_cb(PRIVACY_PRIVILEGE_MANAGER_CALL_CAUSE_ANSWER, PRIVACY_PRIVILEGE_MANAGER_REQUEST_RESULT_ALLOW_FOREVER, response_block->privilege, response_block);
    		break;
    	case PRIVACY_PRIVILEGE_MANAGER_CHECK_RESULT_DENY:
    		permission_request_response_cb(PRIVACY_PRIVILEGE_MANAGER_CALL_CAUSE_ANSWER,  PRIVACY_PRIVILEGE_MANAGER_REQUEST_RESULT_DENY_FOREVER, response_block->privilege, response_block);
    		break;
    	case PRIVACY_PRIVILEGE_MANAGER_CHECK_RESULT_ASK:
    		ret = ppm_request_permission(response_block->privilege, permission_request_response_cb, (void *) response_block);
    		if (ret != 0)
    			logger.log(Logger::Module::SYSTEM, "ppm_request_permission() failed: %d", ret);
    		break;
    	}
    }
    else
    	logger.log(Logger::Module::SYSTEM, "ppm_check_permission() failed: %d", ret);
}

//
// Await permissions: Do not proceed until we've received permission
//                    to access all required APIs and resources
//
static Eina_Bool startup_permissions_timer_fn(void *data)
{
	Logger &logger = Logger::getInstance();

	bool all_permissions_granted = true;
	for (int i=0; i<sizeof(required_permissions)/sizeof(required_permissions[0]); i++)
	{
		if (!required_permissions[i].granted)
			all_permissions_granted = false;
	}

	if (all_permissions_granted)
	{
		logger.log(Logger::Module::SYSTEM, "All permissions granted. Continuing with launch...");

		ecore_timer_del(startup_timer);
		startup_timer = NULL;

		launch_app();

		return ECORE_CALLBACK_CANCEL;
	}

	return ECORE_CALLBACK_RENEW;
}

//
// Permission request: Request permission to access all required APIs and resources
//
void request_app_permissions()
{
	Logger::getInstance().log(Logger::Module::SYSTEM, "Requesting app permissions...");

	startup_timer = ecore_timer_add(1.0, startup_permissions_timer_fn, NULL);

	for (int i=0; i<sizeof(required_permissions)/sizeof(required_permissions[0]); i++)
		request_app_permission(&required_permissions[i]);
}

