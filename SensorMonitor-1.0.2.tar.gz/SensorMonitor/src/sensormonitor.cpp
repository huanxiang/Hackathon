/*
 * sensormonitor.cpp
 *
 *   Created on: May 27, 2019
 *       Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   A simple sensor monitoring program for Tizen 4 wearable devices.
 *
 *   This app runs in the background on a Tizen 4 wearable, and continuously records the PPG and Accelerometer
 *   data to a local SQLite database file. It runs whenever the device is off the charger.
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */
#include <tizen.h>
#include <service_app.h>

#include <permissions.hpp>
#include <sensor_data_writer.hpp>

#include <db.hpp>
#include <data_capture.hpp>
#include <logger.hpp>
#include <utils.hpp>

#include <device/battery.h>
#include <sensormonitor.hpp>

//
// Main startup sequence. This is called when the permissions required by the app
// have been granted (Tizen 4 requires permissions to be granted at run-time on
// the first run, much like Android now does.)
//
void launch_app()
{
	Logger &logger = Logger::getInstance();
	DB &db = DB::getInstance();
	DataCapture &dc = DataCapture::getInstance();
	Utils &utils = Utils::getInstance();

	logger.log(Logger::Module::SYSTEM, "Launching app...");

	logger.open();

	// Prevent logs from filling local storage
	logger.purge_old_logs();

	// Create/open SQLite DB
	db.open();

	// Record snapshot of system boot time (UNIX epoch and rolling system timestamp format)
	db.record_boot_time();

	// Record the timezone we're running in on each startup
	utils.detect_timezone_change();

	//
	// Start recording immediately if we are started off-charger
	//
	device_battery_power_source_e power_source;
	int rc = device_battery_get_power_source(&power_source);
	if ((rc == DEVICE_ERROR_NONE) && (power_source == DEVICE_BATTERY_POWER_SOURCE_NONE))
	{
		logger.log(Logger::Module::SYSTEM, "Started off-charger. Starting data capture...");
		dc.start();
	}

	logger.log(Logger::Module::SYSTEM, "App launched");
}

//
// This callback fires when the service app is created by Tizen. All we
// do here is request our permissions - launch_app() will be called when
// they are granted.
//
bool service_app_create(void *data)
{
	request_app_permissions();
    return true;
}

//
// Service termination. Called by Tizen O/S.
//
void service_app_terminate(void *data)
{
	DataCapture::getInstance().stop();
	DB::getInstance().close();
	Logger::getInstance().close();
}

//
// System events. We just log these as we don't do anything with them.
//
void service_app_control(app_control_h app_control, void *data)
{
	Logger::getInstance().log(Logger::Module::SYSTEM, "%s() called", __FUNCTION__);
}

static void service_app_lang_changed(app_event_info_h event_info, void *user_data)
{
	Logger::getInstance().log(Logger::Module::SYSTEM, "%s() called", __FUNCTION__);
}

static void service_app_region_changed(app_event_info_h event_info, void *user_data)
{
	Logger::getInstance().log(Logger::Module::SYSTEM, "%s() called", __FUNCTION__);
}

static void service_app_low_battery(app_event_info_h event_info, void *user_data)
{
	Logger::getInstance().log(Logger::Module::SYSTEM, "%s() called", __FUNCTION__);
}

static void service_app_low_memory(app_event_info_h event_info, void *user_data)
{
	Logger::getInstance().log(Logger::Module::SYSTEM, "%s() called", __FUNCTION__);
}

//
// Set up our service app callbacks and enter the main loop
//
int main(int argc, char* argv[])
{
	char ad[50] = {0,};
	service_app_lifecycle_callback_s event_callback;
	app_event_handler_h handlers[5] = {NULL, };

	event_callback.create      = service_app_create;
	event_callback.terminate   = service_app_terminate;
	event_callback.app_control = service_app_control;

	service_app_add_event_handler(&handlers[APP_EVENT_LOW_BATTERY],                     APP_EVENT_LOW_BATTERY,    service_app_low_battery, &ad);
	service_app_add_event_handler(&handlers[APP_EVENT_LOW_MEMORY],                       APP_EVENT_LOW_MEMORY,     service_app_low_memory, &ad);
	service_app_add_event_handler(&handlers[APP_EVENT_LANGUAGE_CHANGED],           APP_EVENT_LANGUAGE_CHANGED,   service_app_lang_changed, &ad);
	service_app_add_event_handler(&handlers[APP_EVENT_REGION_FORMAT_CHANGED], APP_EVENT_REGION_FORMAT_CHANGED, service_app_region_changed, &ad);

	return service_app_main(argc, argv, &event_callback, ad);
}
