/*
 * lock_cpu.cpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#include <lock_cpu.hpp>
#include <logger.hpp>

#include <device/power.h>

static int cpu_lock_ref_count;

bool lock_cpu()
{
	int cpu_lock_error = 0;

	Logger &logger = Logger::getInstance();

	if (++cpu_lock_ref_count == 1)
	{
		logger.log(Logger::Module::SYSTEM, "CPU lock requested (refcount %d)", cpu_lock_ref_count);

		cpu_lock_error = device_power_request_lock(POWER_LOCK_CPU, 0);
		if (cpu_lock_error)
			logger.log(Logger::Module::SYSTEM, "CPU lock request error! [%d]", cpu_lock_error);
	}
	else
		logger.log(Logger::Module::SYSTEM, "CPU lock request (refcount %d)", cpu_lock_ref_count);

	return !cpu_lock_error;
}

bool unlock_cpu()
{
	int cpu_lock_error = 0;

	Logger &logger = Logger::getInstance();

	if (!cpu_lock_ref_count)
	{
		logger.log(Logger::Module::SYSTEM, "CPU lock release requested with zero ref count!");
		return false;
	}

	if (!(--cpu_lock_ref_count))
	{
		logger.log(Logger::Module::SYSTEM, "CPU lock release requested (refcount %d)", cpu_lock_ref_count);

		cpu_lock_error = device_power_release_lock(POWER_LOCK_CPU);
		if (cpu_lock_error)
			logger.log(Logger::Module::SYSTEM, "CPU lock release error! [%d]", cpu_lock_error);
	}
	else
		logger.log(Logger::Module::SYSTEM, "CPU lock release request (refcount %d)", cpu_lock_ref_count);

	return !cpu_lock_error;
}
