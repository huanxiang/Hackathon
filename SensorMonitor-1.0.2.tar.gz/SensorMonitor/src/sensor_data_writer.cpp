/*
 * sensor_data_writer.cpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#include <sensor_data_writer.hpp>
#include <utils.hpp>

SensorDataWriter::SensorDataWriter(DB & write_db): db(write_db)
{
}

//
// Combine the separate streams for raw green reflectance and computed heart-rate into a single DB row for write
//
void PPGDataWriter::write(sensor_type_e sensor_type, unsigned long long int timestamp, float *data, int num_vals)
{
	Utils &utils = Utils::getInstance();

	if (sensor_type == SENSOR_HRM)
	{
		hr_value = (int)data[0];
		hr_value_present = true;
	}
	else
	{
		ppg_green_value = utils.float_as_intf(data[0]);
		ppg_green_value_present = true;
	}

	if (hr_value_present && ppg_green_value_present)
	{
		PPG_SAMPLE sample;

		sample.sys_ts = utils.epoch_time_ms();
		sample.ts = timestamp;
		sample.hr = hr_value;
		sample.green_channel = ppg_green_value;

		db.write_ppg_row(sample);

		hr_value_present = ppg_green_value_present = false;
	}
}

void AccelerometerDataWriter::write(sensor_type_e sensor_type, unsigned long long int timestamp, float *data, int num_vals)
{
	Utils &utils = Utils::getInstance();

	ACC_SAMPLE sample;

	sample.sys_ts = utils.epoch_time_ms();
	sample.ts = timestamp;
	sample.x = Utils::getInstance().float_as_intf(data[0]);
	sample.y = Utils::getInstance().float_as_intf(data[1]);
	sample.z = Utils::getInstance().float_as_intf(data[2]);

	db.write_acc_row(sample);
}
