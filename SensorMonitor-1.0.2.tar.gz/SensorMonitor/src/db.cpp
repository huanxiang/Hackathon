/*
 * db.cpp
 *
 *  Created on: May 27, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */
#include <db.hpp>

#include <logger.hpp>
#include <data_capture.hpp>
#include <utils.hpp>

#include <cstdlib>
#include <cstdio>
#include <cstddef>
#include <cstring>

#include <storage.h>
#include <system_info.h>

DB::DB()
{
	db = NULL;
	stmt_insert_ppg = NULL;
	stmt_insert_acc = NULL;
	stmt_insert_boot_time = NULL;
}

DB::~DB()
{
}

void DB::record_boot_time()
{
	Logger &logger = Logger::getInstance();

	struct timespec tspec_boot;
	clock_gettime(CLOCK_BOOTTIME,  &tspec_boot);

	unsigned long long boot_timestamp = ((unsigned long long)tspec_boot.tv_sec * 1000ULL) + ((unsigned long long)tspec_boot.tv_nsec / 1000000ULL);

	logger.log(Logger::Module::SYSTEM, "Recording boot time: %llu", boot_timestamp);

	sqlite3_bind_int64(stmt_insert_boot_time, 1, Utils::getInstance().epoch_time_ms());
	sqlite3_bind_int64(stmt_insert_boot_time, 2, boot_timestamp);

	int rc = sqlite3_step(stmt_insert_boot_time);
	if (rc != SQLITE_DONE)
	{
		logger.log(Logger::Module::DB, "Error populating boot_time table: %s", sqlite3_errmsg(db));
		return;
	}

	sqlite3_reset(stmt_insert_boot_time);
}

bool DB::write_timezone_row(TIMEZONE_SAMPLE & sample)
{
	if (!db || !stmt_insert_timezone)
		return false;

	sqlite3_bind_int64(stmt_insert_timezone, 1, sample.sys_ts);
	sqlite3_bind_text(stmt_insert_timezone,  2, sample.timezone, -1, SQLITE_TRANSIENT);
	sqlite3_bind_int(stmt_insert_timezone,   3, (int)sample.is_dst);
	sqlite3_bind_text(stmt_insert_timezone,  4, sample.offset, -1, SQLITE_TRANSIENT);

	int rc = sqlite3_step(stmt_insert_timezone);
	if (rc != SQLITE_DONE)
		Logger::getInstance().log(Logger::Module::STORAGE, "ERROR inserting TIMEZONE data: %s\n", sqlite3_errmsg(db));

	sqlite3_reset(stmt_insert_timezone);

	return (rc == SQLITE_DONE);
}


bool DB::write_ppg_row(PPG_SAMPLE & sample)
{
	if (!db || !stmt_insert_ppg)
		return false;

	sqlite3_bind_int64(stmt_insert_ppg, 1, sample.sys_ts);
	sqlite3_bind_int64(stmt_insert_ppg, 2, sample.ts);
	sqlite3_bind_int(stmt_insert_ppg,   3, sample.hr);
	sqlite3_bind_int(stmt_insert_ppg,   4, sample.green_channel);

	int rc = sqlite3_step(stmt_insert_ppg);
	if (rc != SQLITE_DONE)
		Logger::getInstance().log(Logger::Module::STORAGE, "ERROR inserting PPG data: %s\n", sqlite3_errmsg(db));

	sqlite3_reset(stmt_insert_ppg);

	return (rc == SQLITE_DONE);
}

bool DB::write_acc_row(ACC_SAMPLE & sample)
{
	if (!db || !stmt_insert_acc)
		return false;

	sqlite3_bind_int64(stmt_insert_acc, 1, sample.sys_ts);
	sqlite3_bind_int64(stmt_insert_acc, 2, sample.ts);
	sqlite3_bind_int(stmt_insert_acc,   3, sample.x);
	sqlite3_bind_int(stmt_insert_acc,   4, sample.y);
	sqlite3_bind_int(stmt_insert_acc,   5, sample.z);

	int rc = sqlite3_step(stmt_insert_acc);
	if (rc != SQLITE_DONE)
		Logger::getInstance().log(Logger::Module::STORAGE, "ERROR inserting ACC data: %s\n", sqlite3_errmsg(db));

	sqlite3_reset(stmt_insert_acc);

	return (rc == SQLITE_DONE);
}

bool DB::lookup_last_timezone(char *timezone, bool *is_dst, char *offset, size_t string_buffer_size)
{
	if (!timezone || !is_dst || !offset)
		return false;

	Logger &logger = Logger::getInstance();

	int rc = sqlite3_step(stmt_lookup_last_timezone);
	if (rc != SQLITE_ROW)
	{
		logger.log(Logger::Module::STORAGE, "No record found looking up last time zone");

		*timezone = '\0';
		*is_dst = false;
		*offset = '\0';

		sqlite3_reset(stmt_lookup_last_timezone);
		return false;
	}

	int colType_timezone = sqlite3_column_type(stmt_lookup_last_timezone, 0);
	int colType_is_dst   = sqlite3_column_type(stmt_lookup_last_timezone, 1);
	int colType_offset   = sqlite3_column_type(stmt_lookup_last_timezone, 2);

	if ((colType_timezone == SQLITE_NULL) || (colType_is_dst == SQLITE_NULL) || (colType_offset == SQLITE_NULL))
	{
		logger.log(Logger::Module::STORAGE, "Empty record found looking up last time zone");
		sqlite3_reset(stmt_lookup_last_timezone);
		return false;
	}

	*is_dst = (bool) sqlite3_column_int(stmt_lookup_last_timezone, 1);

	strncpy(timezone, (const char *) sqlite3_column_text(stmt_lookup_last_timezone, 0), string_buffer_size);
	strncpy(offset, (const char *) sqlite3_column_text(stmt_lookup_last_timezone, 2), string_buffer_size);

	sqlite3_reset(stmt_lookup_last_timezone);

	return true;
}

//
// Use SQLite WAL (Write-Ahead Logging) mode:
//
// (https://www.sqlite.org/wal.html)
//
bool DB::set_wal_mode()
{
	Logger &logger = Logger::getInstance();

	sqlite3_stmt *wal_stmt = NULL;
	int rc = sqlite3_prepare_v2(db, "PRAGMA journal_mode=WAL;", -1, &wal_stmt, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error preparing WAL activation pragma: %s", sqlite3_errmsg(db));
		return false;
	}
	rc = sqlite3_step(wal_stmt);
	if (rc != SQLITE_ROW)
	{
		logger.log(Logger::Module::DB, "Failure executing WAL activation pragma");
		return false;
	}
	const char *wal_result = (const char *)sqlite3_column_text(wal_stmt, 0);
	if (strcmp(wal_result, "wal"))
	{
		logger.log(Logger::Module::DB, "Failure setting WAL mode");
		return false;
	}
	else
		logger.log(Logger::Module::DB, "WAL mode set successfully");

	sqlite3_finalize(wal_stmt);

	return true;
}

bool DB::create_tables()
{
	Logger &logger = Logger::getInstance();

	//
	// Metadata
	//
	logger.log(Logger::Module::DB, "Creating meta_data table...");

	const char *create_table_meta_data =
		"CREATE TABLE IF NOT EXISTS meta_data ("
			"device_manufacturer TEXT, device_model TEXT, device_platform TEXT, device_serial TEXT, device_tizen_id TEXT, "
			"hr_range_min, hr_range_max, ppg_range_min, ppg_range_max, acc_range_min, acc_range_max)";
	int rc = sqlite3_exec(db, create_table_meta_data, NULL, NULL, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error creating meta_data table: %s", sqlite3_errmsg(db));
		return false;
	}

	// Populate metadata table
	char *manufacturer = (char *)"unknown";
	char *model_name   = (char *)"unknown";
	char *platform_str = (char *)"unknown";
	char *tizen_id     = (char *)"unknown";
	system_info_get_platform_string("http://tizen.org/system/manufacturer", &manufacturer);
	system_info_get_platform_string("http://tizen.org/system/model_name", &model_name);
	system_info_get_platform_string("http://tizen.org/feature/platform.version", &platform_str);
	system_info_get_platform_string("http://tizen.org/system/tizenid", &tizen_id);

	logger.log(Logger::Module::DB, "Clearing meta_data table...");

	rc = sqlite3_exec(db, "DELETE FROM meta_data", NULL, NULL, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error clearing meta_data table: %s", sqlite3_errmsg(db));
		return false;
	}

	logger.log(Logger::Module::DB, "Populating meta_data table...");

	float min_range_hr, max_range_hr, min_range_ppg, max_range_ppg, min_range_acc, max_range_acc;

	DataCapture &dc = DataCapture::getInstance();

	min_range_hr = dc.get_hr_range_min();
	max_range_hr = dc.get_hr_range_max();

	min_range_ppg = dc.get_ppg_green_range_min();
	max_range_ppg = dc.get_ppg_green_range_max();

	min_range_acc = dc.get_ppg_green_range_min();
	max_range_acc = dc.get_ppg_green_range_max();

	char populate_table_metadata_sql[1024];
	snprintf(populate_table_metadata_sql, 1024,
			"INSERT INTO meta_data ("
			"device_manufacturer, device_model, device_platform, device_serial, device_tizen_id, "
			"hr_range_min, hr_range_max, ppg_range_min, ppg_range_max, acc_range_min, acc_range_max"
			") VALUES ("
			"'%s', '%s', '%s', '%s', '%s',"
			"%f, %f, %f, %f, %f, %f)",
			manufacturer, model_name, platform_str, Utils::getInstance().get_watch_serial(), tizen_id,
			min_range_hr, max_range_hr, min_range_ppg, max_range_ppg, min_range_acc, max_range_acc);

	rc = sqlite3_exec(db, populate_table_metadata_sql, NULL, NULL, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error populating meta_data table: %s", sqlite3_errmsg(db));
		return false;
	}

	//
	// Boot time
	//
	logger.log(Logger::Module::DB, "Creating boot_time table...");

	rc = sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS boot_time (system_time INTEGER, timestamp INTEGER)", NULL, NULL, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error creating restart_time table: %s", sqlite3_errmsg(db));
		return false;
	}

	//
	// HR / PPG
	//
	logger.log(Logger::Module::DB, "Creating HR/PPG data table...");

	const char *create_table_sql_hr = "CREATE TABLE IF NOT EXISTS hr_ppg (sample_id INTEGER PRIMARY KEY AUTOINCREMENT, system_time INTEGER, timestamp INTEGER, heart_rate INTEGER, green_channel INTEGER)";
	rc = sqlite3_exec(db, create_table_sql_hr, NULL, NULL, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error creating HR table: %s", sqlite3_errmsg(db));
		return false;
	}

	//
	// Accelerometer
	//
	logger.log(Logger::Module::DB, "Creating accelerometer data table...");

	const char *create_table_sql_acc = "CREATE TABLE IF NOT EXISTS accelerometer (sample_id INTEGER PRIMARY KEY AUTOINCREMENT, system_time INTEGER, timestamp INTEGER, value_0 INTEGER, value_1 INTEGER, value_2 INTEGER)";
	rc = sqlite3_exec(db, create_table_sql_acc, NULL, NULL, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error creating ACC table: %s", sqlite3_errmsg(db));
		return false;
	}

	//
	// Timezone change data
	//
	const char *create_table_sql_timezone = "CREATE TABLE IF NOT EXISTS timezone_changes (sample_id INTEGER PRIMARY KEY AUTOINCREMENT, system_time INTEGER, timezone TEXT, is_dst INTEGER, offset TEXT)";
	rc = sqlite3_exec(db, create_table_sql_timezone, NULL, NULL, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error creating TIMEZONE table: %s", sqlite3_errmsg(db));
		return false;
	}

	return true;
}

bool DB::prepare_sql()
{
	Logger &logger = Logger::getInstance();
	int rc;

	rc = sqlite3_prepare_v2(db, "insert into hr_ppg (system_time, timestamp, heart_rate, green_channel) values (?1, ?2, ?3, ?4)", -1, &stmt_insert_ppg, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error preparing 'insert ppg' statement: %s", sqlite3_errmsg(db));
		return false;
	}
	rc = sqlite3_prepare_v2(db, "insert into accelerometer (system_time, timestamp, value_0, value_1, value_2) values (?1, ?2, ?3, ?4, ?5)", -1, &stmt_insert_acc, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error preparing 'insert acc' statement: %s", sqlite3_errmsg(db));
		return false;
	}
	rc = sqlite3_prepare_v2(db, "insert into boot_time (system_time, timestamp) values (?1, ?2)", -1, &stmt_insert_boot_time, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error preparing 'insert boot time' statement: %s", sqlite3_errmsg(db));
		return false;
	}
	rc = sqlite3_prepare_v2(db, "insert into timezone_changes (system_time, timezone, is_dst, offset) values (?1, ?2, ?3, ?4)", -1, &stmt_insert_timezone, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error preparing 'insert time zone' statement: %s", sqlite3_errmsg(db));
		return false;
	}
	rc = sqlite3_prepare_v2(db, "select timezone, is_dst, offset from timezone_changes order by system_time desc limit 1", -1, &stmt_lookup_last_timezone, NULL);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error preparing 'lookup last time zone' statement: %s", sqlite3_errmsg(db));
		return false;
	}

	logger.log(Logger::Module::DB, "SQL statements prepared");

	return true;
}

bool DB::open()
{
	if (db)
		return true;

	Logger &logger = Logger::getInstance();

	// Get storage path
	char *storage_path;
	storage_get_directory(0, STORAGE_DIRECTORY_DOCUMENTS, &storage_path);

	const char * db_file_basename = "data_capture";

	// Open SQLite DB
	char db_fn[256];
	snprintf(db_fn, sizeof(db_fn), "%s/%s_%s.db", storage_path, db_file_basename, Utils::getInstance().get_watch_serial());

	free(storage_path);

	int rc = sqlite3_open(db_fn, &db);
	if (rc != SQLITE_OK)
	{
		logger.log(Logger::Module::DB, "Error opening SQLite DB: %s", sqlite3_errmsg(db));
		return false;
	}

	set_wal_mode();
	create_tables();
	prepare_sql();

	return true;
}

void DB::close()
{
	if (!db)
		return;

	sqlite3_finalize(stmt_insert_ppg);
	sqlite3_finalize(stmt_insert_acc);
	sqlite3_finalize(stmt_insert_boot_time);

	stmt_insert_ppg = NULL;
	stmt_insert_acc = NULL;
	stmt_insert_boot_time = NULL;

	db = NULL;
}
