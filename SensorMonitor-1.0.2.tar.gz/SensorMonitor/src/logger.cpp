/*
 * logger.cpp
 *
 *  Created on: May 27, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#include <logger.hpp>

#include <thread>
#include <ctime>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>

#include <dlog.h>
#include <sensormonitor.hpp>
#include <storage.h>

// DLog tag
#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "sensormonitor"

Logger::Logger()
{
	log_file = NULL;
	file_open = false;
}

Logger::~Logger()
{

}

bool Logger::open()
{
	std::lock_guard<std::mutex> lock(mutex);

	const char *LOG_FILENAME_BASE = "monitor";

	char log_fn[PATH_MAX];
	char *storage_path;
	storage_get_directory(0, STORAGE_DIRECTORY_DOCUMENTS, &storage_path);
	snprintf(log_dir, sizeof(log_dir), "%s/%s", storage_path, "logs");
	free(storage_path);

	mkdir(log_dir, 0755);

	time_t rawtime;
	struct tm *timeinfo;
	char logTimeStr[80];

	time(&rawtime);
	timeinfo = localtime(&rawtime);
	strftime(logTimeStr, sizeof(logTimeStr), "%Y-%m-%d_%H_%M_%S", timeinfo);
	snprintf(log_fn, 256, "%s/%s_%s.txt", log_dir, LOG_FILENAME_BASE, logTimeStr);

	log_file = fopen(log_fn, "w");
	file_open = true;

	return true;
}

void Logger::close()
{
	std::lock_guard<std::mutex> lock(mutex);

	if (!log_file)
		return;

	fclose(log_file);
	log_file = NULL;
	file_open = false;
}

const char *Logger::module_to_str(Logger::Module &module)
{
	switch (module)
	{
	case Logger::Module::CAPTURE:
		return "capture";
	case Logger::Module::DB:
		return "db";
	case Logger::Module::IMU:
		return "imu";
	case Logger::Module::LOG:
		return "log";
	case Logger::Module::PPG:
		return "ppg";
	case Logger::Module::STORAGE:
		return "storage";
	case Logger::Module::SQL:
		return "sql";
	case Logger::Module::SYSTEM:
		return "system";
	default:
		return "unknown";
	}
}

void Logger::log(Logger::Module module, char const * format, ...)
{
	std::lock_guard<std::mutex> lock(mutex);

	if (file_open && !log_file)
		return;

	va_list va_list;
	time_t rawtime;
	struct tm *tinfo;
	char log_line[1024];

	time(&rawtime);
	tinfo = localtime(&rawtime);
	char *log_time = asctime(tinfo);
	log_time[strlen(log_time)-1] = '\0';

    va_start(va_list, format);
    vsnprintf(log_line, sizeof(log_line), format, va_list);
	va_end(va_list);

	char log_header[64];
	const char *mod_str = module_to_str(module);

	int mod_pad_len = (13 - strlen(mod_str)) / 2;
	snprintf(log_header, sizeof(log_header), "[%s] [%*s%s%*s", log_time,   mod_pad_len, "", mod_str, mod_pad_len, "");

    dlog_print(DLOG_DEBUG, LOG_TAG, "%-41s]: %s", log_header, log_line);

    // This function may be called before the log file is open - if so just log to DLog
    if (file_open)
    {
    	fprintf(log_file, "[%s] %s\n", log_time, log_line);
    	fflush(log_file); // ???
    }
}

// Scan the log direcory for old logs, and delete them to save space on the internal storage
void Logger::purge_old_logs()
{
	DIR *dp;
	struct dirent *ep;
	struct stat statbuf;

	log(Logger::Module::SYSTEM, "Checking for old logs to delete in '%s' ...", log_dir);

	const unsigned long log_delete_cutoff_s = 7 * 24 * 60 * 60ULL;    // Delete old logs after 1 week

	dp = opendir(log_dir);
	if (dp != NULL)
	{
		while ((ep = readdir(dp)))
		{
			char fullpath[PATH_MAX];
			snprintf(fullpath, PATH_MAX, "%s/%s", log_dir, ep->d_name);
			if (stat(fullpath, &statbuf) == -1)
			{
				log(Logger::Module::SYSTEM, "Failed to stat '%s' (%s) ...", fullpath, strerror(errno));
				continue;
			}
			if ((strlen(ep->d_name) < 4) || strcmp((ep->d_name + strlen(ep->d_name) - 4), ".txt"))
			{
				log(Logger::Module::SYSTEM, "Skipping: '%s' ...", fullpath);
				continue;
			}

			time_t time_now = time(NULL);
			time_t time_last_modified = statbuf.st_mtim.tv_sec;
			time_t last_modified_s = time_now - time_last_modified;
			time_t hours_old = (time_t)(last_modified_s / 3600.0);

			if (time_last_modified <= time_now)
			{
				if (last_modified_s > log_delete_cutoff_s)
				{
					log(Logger::Module::SYSTEM, "Deleting: '%s' (%d hours old) ...", fullpath, hours_old);
					unlink(fullpath);
				}
				else
					log(Logger::Module::SYSTEM, "Checked : '%s' (%d hours old) ...", fullpath, hours_old);
			}
			else
				log(Logger::Module::SYSTEM, "File    : '%s' last modified in the future (%d hours) - system clock change?", fullpath, hours_old);
		}
		closedir(dp);
	}
}
