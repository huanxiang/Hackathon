/*
 * clang_mulodi4_hack.cpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 *
 *  FIXME: Hack/workaround for clang/gcc bug in Tizen toolchain where clang inserts
 *  compiler-rt constructs which aren't available in libgcc
 *
 *  The issue seems similar to these in the Android NDK for aarch64:
 *
 *      https://github.com/android-ndk/ndk/issues/506
 *      https://github.com/android-ndk/ndk/issues/294
 *
 */

#include <climits>

extern "C"
{
	long long
	__mulodi4(long long a, long long b, int* overflow)
	{
		const int N = (int)(sizeof(long long) * CHAR_BIT);
		const long long MIN = (long long)1 << (N-1);
		const long long MAX = ~MIN;
		*overflow = 0;
		long long result = a * b;
		if (a == MIN)
		{
			if (b != 0 && b != 1)
				*overflow = 1;
			return result;
		}
		if (b == MIN)
		{
			if (a != 0 && a != 1)
				*overflow = 1;
			return result;
		}
		long long sa = a >> (N - 1);
		long long abs_a = (a ^ sa) - sa;
		long long sb = b >> (N - 1);
		long long abs_b = (b ^ sb) - sb;
		if (abs_a < 2 || abs_b < 2)
			return result;
		if (sa == sb)
		{
			if (abs_a > MAX / abs_b)
				*overflow = 1;
		}
		else
		{
			if (abs_a > MIN / -abs_b)
				*overflow = 1;
		}
		return result;
	}
}
