/*
 * utils.cpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#include <utils.hpp>
#include <logger.hpp>
#include <db.hpp>

#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <sys/time.h>
#include <thread>

#include <utils_i18n.h>

//
// Tizen O/S callback for a timezone change. We track this to allow our
// captured data's timestamps to be interpreted correctly.
//
static void timezone_changed_callback(system_settings_key_e key, void *context)
{
	if (key != SYSTEM_SETTINGS_KEY_LOCALE_TIMEZONE)
		return;

	Utils *utils = (Utils *)context;
	if (!utils)
		return;

	utils->detect_timezone_change();
}

Utils::Utils()
{
	epoch_time_start_us = ((unsigned long long)time(NULL))*1000000;
	gettimeofday(&tval_start, NULL);
	system_settings_set_changed_cb(SYSTEM_SETTINGS_KEY_LOCALE_TIMEZONE, timezone_changed_callback, this);
}

//
// Returns the watch serial number. This is officially unsupported, and a bit of a hack.
//
const char * Utils::get_watch_serial()
{
	if (!(*watch_serial_no))
	{
		static const char * serial_no_cmd =
				"dbus-send --system --print-reply --reply-timeout=2000  --type=method_call "
				"--dest=org.tizen.system.deviced /Org/Tizen/System/DeviceD/Board org.tizen.system.deviced.Board.GetSerial";

		FILE *fp = popen(serial_no_cmd, "r");
		char *ln = NULL;
		size_t len = 0;

		if (getline(&ln, &len, fp) != -1)
		{
			if (getline(&ln, &len, fp) != -1)
			{
				memset(watch_serial_no, 0, sizeof(watch_serial_no));
				strncpy(watch_serial_no, ln+11, 11);
				free(ln);
			}
		}
		pclose(fp);

		Logger::getInstance().log(Logger::Module::SYSTEM, "Detected serial no: '%s'", watch_serial_no);
	}

	return watch_serial_no;
}

//
// This method encodes an IEEE 754 binary32 single-precision float as a 32-bit integer
//
int Utils::float_as_intf(float val)
{
	float val_f = val;
	int *float_bytes = (int *) &val_f;
	return *float_bytes;
}

//
// This method returns the current time in UNIX epoch format
//
unsigned long long Utils::epoch_time_ms()
{
	std::lock_guard<std::mutex> lock(time_mutex);

	struct timeval tval_now, tval_diff;
	gettimeofday(&tval_now, NULL);

	timersub(&tval_now, &tval_start, &tval_diff);

	unsigned long long ts_us =  epoch_time_start_us +
								(((unsigned long long)tval_diff.tv_sec)*1000000) +
								(unsigned long long)tval_diff.tv_usec;

	return ts_us / 1000;
}

//
// This method runs on a time zone change. It checks whether the new
// time zone is indeed different from the previous one we recorded,
// and if so logs the change in the SQLite database.
//
void Utils::detect_timezone_change()
{
	int rc;
	char *tz_str;

	Logger &logger = Logger::getInstance();

	unsigned long long current_time = epoch_time_ms();

	rc = system_settings_get_value_string(SYSTEM_SETTINGS_KEY_LOCALE_TIMEZONE, &tz_str);
	if (rc == SYSTEM_SETTINGS_ERROR_NONE)
		logger.log(Logger::Module::SYSTEM, "TIME ZONE CHANGE: %s", tz_str);

	i18n_timezone_h tz;

	rc = i18n_timezone_create_default(&tz);
	if (rc != I18N_ERROR_NONE)
		logger.log(Logger::Module::SYSTEM, "i18n_timezone_create_default failed [%d]", rc);
	else
	{
		int32_t dst;
		int32_t offset_ms;
		bool is_dst = false;
		const int32_t dst_cmp = 3600000;  // 1 hour

		rc = i18n_timezone_get_dst_savings(tz, &dst);
		if (rc != I18N_ERROR_NONE)
			logger.log(Logger::Module::SYSTEM, "i18n_timezone_get_dst_savings failed [%d]", rc);
		else
		{
			is_dst = (dst == dst_cmp);
			logger.log(Logger::Module::SYSTEM, "Daylight savings time: %s", is_dst ? "true" : "false");
		}

		int offset_h, offset_m;

		rc = i18n_timezone_get_raw_offset(tz, &offset_ms);
		if (rc != I18N_ERROR_NONE)
			logger.log(Logger::Module::SYSTEM, "i18n_timezone_get_raw_offset failed [%d]", rc);
		else
		{
			const int MS_IN_HOUR = 60*60*1000;
			const int MS_IN_MIN = 60*1000;

			if (is_dst)
				offset_ms += MS_IN_HOUR;

			offset_h = (int)(offset_ms / MS_IN_HOUR);
			offset_m = (int)((offset_ms % MS_IN_HOUR) / MS_IN_MIN);
			bool neg = (offset_h < 0) || (offset_m < 0);

			offset_h = abs(offset_h);
			offset_m = abs(offset_m);

			char offset_str[8];
			snprintf(offset_str, sizeof(offset_str), "%s%02d:%02d", neg ? "-" : "", offset_h, offset_m);

			logger.log(Logger::Module::SYSTEM, "UTC offset: %s", offset_str);

			//
			// Check whether the timezone has indeed changed since we last
			// checked - if so, update the last timezone and insert sample
			//
			bool perform_update = false;

			DB &db = DB::getInstance();

			char last_tz_str[32], last_offset_str[32];
			bool last_is_dst;
			bool success = db.lookup_last_timezone(last_tz_str, &last_is_dst, last_offset_str, sizeof(last_tz_str));
			if (success)
			{
				int tz_cmp = strncmp(last_tz_str, tz_str, sizeof(last_tz_str));
				int offset_cmp = strncmp(last_offset_str, offset_str, sizeof(last_offset_str));
				perform_update = tz_cmp || offset_cmp || (is_dst != last_is_dst);
			}
			else
			{
				logger.log(Logger::Module::SYSTEM, "No last time zone record found. Assuming update required...");
				perform_update = true;
			}

			if (perform_update)
			{
				logger.log(Logger::Module::SYSTEM, "Updating time zone...");

				TIMEZONE_SAMPLE tz_sample;

				tz_sample.sys_ts = current_time;
				strncpy(tz_sample.timezone, tz_str, sizeof(tz_sample.timezone));
				tz_sample.is_dst = is_dst;
				strncpy(tz_sample.offset, offset_str, sizeof(tz_sample.offset));

				db.write_timezone_row(tz_sample);
			}
			else
				logger.log(Logger::Module::SYSTEM, "Time zone same as last sample. Not updating...");
		}
	}
}

