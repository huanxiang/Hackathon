/*
 * sensor_capture.cpp
 *
 *  Created on: May 27, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#include <logger.hpp>
#include <sensor_capture.hpp>

SensorCapture::SensorCapture(sensor_type_e sensor, int capture_interval, std::shared_ptr<SensorDataWriter> data_writer):
	writer(data_writer)
{
	sensor_type = sensor;
	interval = capture_interval;
	active = false;

	Logger::getInstance().log(Logger::Module::CAPTURE, "%s SensorCapture created", get_sensor_desc());
}

SensorCapture::~SensorCapture()
{
	Logger::getInstance().log(Logger::Module::CAPTURE, "%s SensorCapture destroyed", get_sensor_desc());
}

static void sensor_callback(sensor_h sensor, sensor_event_s *event, void *context)
{
	SensorCapture *sensor_capture = (SensorCapture *)context;
	if (!sensor_capture)
		return;
	sensor_capture->write_data(event->timestamp, event->values, event->value_count);
}

void SensorCapture::write_data(unsigned long long int timestamp, float *data, int num_vals)
{
	writer->write(sensor_type, timestamp, data, num_vals);
}

const char *SensorCapture::get_sensor_desc()
{
	switch (sensor_type)
	{
	case SENSOR_HRM:
		return "HR";
	case SENSOR_HRM_LED_GREEN:
		return "PPG green";
	case SENSOR_ACCELEROMETER:
		return "Accelerometer";
	default:
		return "unknown";
	}
}

bool SensorCapture::initialise()
{
	bool supported;
	int ret;

	ret = sensor_is_supported(sensor_type, &supported);
	if (ret != SENSOR_ERROR_NONE)
		return false;
	if (!supported)
		return false;

	ret = sensor_get_default_sensor(sensor_type, &sensor_handle);
	if (ret != SENSOR_ERROR_NONE)
		return false;

	ret = sensor_create_listener(sensor_handle, &listener_handle);
	if (ret != SENSOR_ERROR_NONE)
		return false;

	ret = sensor_listener_set_event_cb(listener_handle, interval, sensor_callback, this);
	if (ret != SENSOR_ERROR_NONE)
	{
		sensor_destroy_listener(listener_handle);
		return false;
	}

	sensor_get_min_range(sensor_handle, &min_range);
	sensor_get_max_range(sensor_handle, &max_range);

	const char *sensor_desc = get_sensor_desc();
	Logger::getInstance().log(Logger::Module::CAPTURE, "%s sensor listener initialised - sensor handle %p, listener handle %p", sensor_desc, sensor_handle, listener_handle);

	return true;
}

bool SensorCapture::start_capture()
{
	Logger &logger = Logger::getInstance();
	const char *sensor_desc = get_sensor_desc();

	int ret = sensor_listener_start(listener_handle);
	if (ret != SENSOR_ERROR_NONE)
	{
		logger.log(Logger::Module::CAPTURE, "Failed to start %s sensor listener", sensor_desc);
	}
	else
	{
		ret = sensor_listener_set_option(listener_handle, SENSOR_OPTION_ALWAYS_ON);
		if (ret != SENSOR_ERROR_NONE)
		{
			logger.log(Logger::Module::CAPTURE, "Failed to set %s sensor SENSOR_OPTION_ALWAYS_ON option", sensor_desc);
			return false;
		}

		ret = sensor_listener_set_attribute_int(listener_handle, SENSOR_ATTRIBUTE_PAUSE_POLICY, SENSOR_PAUSE_NONE);
		if (ret != SENSOR_ERROR_NONE)
		{
			logger.log(Logger::Module::CAPTURE, "Failed to set %s sensor SENSOR_ATTRIBUTE_PAUSE_POLICY to SENSOR_PAUSE_NONE", sensor_desc);
			return false;
		}
		active = true;

		logger.log(Logger::Module::CAPTURE, "%s sensor listener started", sensor_desc);
	}

	return (ret == SENSOR_ERROR_NONE);
}

bool SensorCapture::stop_capture()
{
	Logger &logger = Logger::getInstance();

	int ret = sensor_listener_stop(listener_handle);
	if (ret != SENSOR_ERROR_NONE)
		logger.log(Logger::Module::CAPTURE, "Failed to stop %s listener", get_sensor_desc());
	else
	{
		active = false;
		logger.log(Logger::Module::CAPTURE, "%s sensor listener stopped", get_sensor_desc());
	}

	return (ret == SENSOR_ERROR_NONE);
}

void SensorCapture::destroy()
{
	sensor_destroy_listener(listener_handle);
	Logger::getInstance().log(Logger::Module::CAPTURE, "%s sensor listener destroyed", get_sensor_desc());
}
