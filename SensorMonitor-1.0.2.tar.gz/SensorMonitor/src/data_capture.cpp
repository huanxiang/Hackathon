/*
 * data_capture.cpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *  This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *  For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#include <data_capture.hpp>
#include <logger.hpp>
#include <lock_cpu.hpp>

#include <device/callback.h>
#include <efl_extension.h>
#include <device/battery.h>

static Ecore_Timer *charger_state_timer;

//
// Check periodically whether the wearable been placed on the charger. If so, stop
// data capture. Resume capture when the wearable is removed from the charger.
//
static Eina_Bool check_charger_state_timer_fn(void *context)
{
	device_battery_power_source_e power_source;
	int rc = device_battery_get_power_source(&power_source);
	if (rc != DEVICE_ERROR_NONE)
		return ECORE_CALLBACK_RENEW;

	DataCapture *data_capture = (DataCapture *)context;
	if (!data_capture)
	{
		Logger::getInstance().log(Logger::Module::CAPTURE, "Invalid DataCapture context in charge state timer function - assuming shutdown is in progress...");
		return ECORE_CALLBACK_RENEW;
	}

	if (power_source == DEVICE_BATTERY_POWER_SOURCE_NONE)
	{
		if (!data_capture->is_active())
		{
			Logger::getInstance().log(Logger::Module::CAPTURE, "Watch removed from charger - starting data capture...");
			data_capture->start();
		}
	}
	else
	{
		if (data_capture->is_active())
		{
			Logger::getInstance().log(Logger::Module::CAPTURE, "Watch placed on charger - stopping data capture...");
			data_capture->stop();
		}
	}

	return ECORE_CALLBACK_RENEW;
}

DataCapture::DataCapture():
		active(false)
{
	DB &db = DB::getInstance();

	auto ppg_data_writer = std::make_shared<PPGDataWriter>(db);
	auto acc_data_writer = std::make_shared<AccelerometerDataWriter>(db);

	const int PPG_SENSOR_INTERVAL = 50;
	const int IMU_SENSOR_INTERVAL = 20;

	capture_hr        = std::make_unique<SensorCapture>(SENSOR_HRM,           PPG_SENSOR_INTERVAL, ppg_data_writer);
	capture_ppg_green = std::make_unique<SensorCapture>(SENSOR_HRM_LED_GREEN, PPG_SENSOR_INTERVAL, ppg_data_writer);
	capture_acc       = std::make_unique<SensorCapture>(SENSOR_ACCELEROMETER, IMU_SENSOR_INTERVAL, acc_data_writer);

	capture_hr->initialise();
	capture_ppg_green->initialise();
	capture_acc->initialise();

	charger_state_timer = ecore_timer_add(1.0, check_charger_state_timer_fn, this);
}

DataCapture::~DataCapture()
{
	ecore_timer_del(charger_state_timer);

	capture_hr->destroy();
	capture_ppg_green->destroy();
	capture_acc->destroy();
}

bool DataCapture::start()
{
	lock_cpu();

	capture_hr->start_capture();
	capture_ppg_green->start_capture();
	capture_acc->start_capture();

	active = true;

	return true;
}

void DataCapture::stop()
{
	capture_hr->stop_capture();
	capture_ppg_green->stop_capture();
	capture_acc->stop_capture();

	active = false;

	unlock_cpu();
}
