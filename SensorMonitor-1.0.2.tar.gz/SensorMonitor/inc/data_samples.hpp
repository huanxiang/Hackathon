/*
 * data_samples.hpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __DATA_SAMPLES_HPP__
#define __DATA_SAMPLES_HPP__

typedef struct _PPG_SAMPLE
{
	unsigned long long sys_ts;
	unsigned long long ts;
	int hr;
	int green_channel;
} PPG_SAMPLE;

typedef struct _ACC_SAMPLE
{
	unsigned long long sys_ts;
	unsigned long long ts;
	int x;
	int y;
	int z;
} ACC_SAMPLE;

typedef struct _TIMEZONE_SAMPLE
{
	unsigned long long sys_ts;
	char timezone[48];
	bool is_dst;
	char offset[8];
} TIMEZONE_SAMPLE;

#endif // !__DATA_SAMPLES_HPP__
