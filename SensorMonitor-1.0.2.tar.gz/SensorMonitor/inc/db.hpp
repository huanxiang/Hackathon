/*
 * db.hpp
 *
 *  Created on: May 27, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __DB_H__
#define __DB_H__

#include <data_samples.hpp>

#include <cstddef>

#include <sqlite3.h>

//
// This class maintains a SQLite database on local storage to contain the
// recorded sensor data and metadata.
//
class DB
{
public:
	DB();
	~DB();

	static DB & getInstance()
	{
		static DB instance;
		return instance;
	}

	bool open();
	void close();

	// Write PPG data
	bool write_ppg_row(PPG_SAMPLE &sample);

	// Write Accelerometer data
	bool write_acc_row(ACC_SAMPLE &sample);

	// Write timezone data
	bool write_timezone_row(TIMEZONE_SAMPLE & sample);
	bool lookup_last_timezone(char *timezone, bool *is_dst, char *offset, size_t string_buffer_size);

	// Record the time the system booted - this allows Tizen timestamps (relative to boot time) to be interpreted
	void record_boot_time();
	bool lookup_last_boot_time(unsigned long long &boot_time);

private:
	sqlite3 *db;

	sqlite3_stmt *stmt_insert_ppg;
	sqlite3_stmt *stmt_insert_acc;
	sqlite3_stmt *stmt_insert_boot_time;
	sqlite3_stmt *stmt_insert_timezone;
	sqlite3_stmt *stmt_lookup_last_timezone;

	bool set_wal_mode();
	bool create_tables();
	bool prepare_sql();
};

#endif // !__DB_H__
