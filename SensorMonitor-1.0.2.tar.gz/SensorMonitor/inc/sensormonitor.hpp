/*
 * sensormonitor.hpp
 *
 *  Created on: May 27, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __SENSOR_MONITOR_H__
#define __SENSOR_MONITOR_H__

void launch_app();

#endif // !__SENSOR_MONITOR_H__
