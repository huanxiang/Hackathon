/*
 * data_capture.hpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __DATA_CAPTURE_HPP__
#define __DATA_CAPTURE_HPP__

#include <sensor_capture.hpp>

#include <memory>

//
// This class manages global data capture - it allows capture from all monitored
// sensors to be switched on and off depending on whether the wearable is on the
// charger or not.
//
class DataCapture
{
public:
	DataCapture();
	~DataCapture();

	static DataCapture & getInstance()
	{
		static DataCapture instance;
		return instance;
	}

	bool start();
	void stop();

	float get_hr_range_min()        { return capture_hr ? capture_hr->get_range_min() : -1.0f; }
	float get_hr_range_max()        { return capture_hr ? capture_hr->get_range_max() : -1.0f; }

	float get_ppg_green_range_min() { return capture_ppg_green ? capture_ppg_green->get_range_min() : -1.0f; }
	float get_ppg_green_range_max() { return capture_ppg_green ? capture_ppg_green->get_range_max() : -1.0f; }

	float get_acc_range_min()       { return capture_acc ? capture_acc->get_range_min() : -1.0f; }
	float get_acc_range_max()       { return capture_acc ? capture_acc->get_range_max() : -1.0f; }

	bool is_active() const { return active; }

private:
	bool active;

	std::unique_ptr<SensorCapture> capture_hr;
	std::unique_ptr<SensorCapture> capture_ppg_green;
	std::unique_ptr<SensorCapture> capture_acc;
};

#endif // !__DATA_CAPTURE_HPP__
