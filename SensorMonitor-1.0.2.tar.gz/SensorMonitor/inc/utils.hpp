/*
 * utils.hpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __UTILS_HPP__
#define __UTILS_HPP__

#include <mutex>

#include <system_settings.h>

//
// Singleton class containing miscellaneous utility functions.
//
class Utils
{
public:
	Utils();
	~Utils() {}

	static Utils & getInstance()
	{
		static Utils instance;
		return instance;
	}

	// Return the watch serial number
	const char * get_watch_serial();

	// Encode an IEEE 754 binary32 single-precision float as a 32-bit integer
	int float_as_intf(float val);

	// Return the current time in UNIX epoch format, extended for milliseconds
	unsigned long long epoch_time_ms();

	// Process/log a timezone change
	void detect_timezone_change();

private:
	char watch_serial_no[128];

	std::mutex time_mutex;
	unsigned long long epoch_time_start_us;
	timeval tval_start;
};

#endif // !__UTILS_HPP__
