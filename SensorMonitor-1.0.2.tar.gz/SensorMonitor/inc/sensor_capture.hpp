/*
 * sensor_capture.hpp
 *
 *  Created on: May 27, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __PPG_H__
#define __PPG_H__

#include <sensor_data_writer.hpp>

#include <sensor.h>

#include <memory>

//
// This class wraps the Tizen O/S sensor data capture APIs, allowing any sensor to
// be monitored and provide data. It takes a SensorDataWriter as a parameter to
// allow it to write the resulting data stream to the SQLite database.
//
class SensorCapture
{
public:
	SensorCapture(sensor_type_e sensor_type, int capture_interval, std::shared_ptr<SensorDataWriter> data_writer);
	~SensorCapture();

	bool initialise();
	void destroy();

	bool start_capture();
	bool stop_capture();
	bool capture_active() const { return active; }

	float get_range_min() const { return min_range; }
	float get_range_max() const { return max_range; }

	const char *get_sensor_desc();

	void write_data(unsigned long long int timestamp, float *data, int num_vals);

private:
	sensor_type_e sensor_type;
	int interval;

	sensor_h sensor_handle;
	sensor_listener_h listener_handle;

	float max_range;
	float min_range;

	bool active;

	std::shared_ptr<SensorDataWriter> writer;
};

#endif // !__PPG_H__
