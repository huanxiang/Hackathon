/*
 * SensorDataWriter.hpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __SENSORDATAWRITER_HPP__
#define __SENSORDATAWRITER_HPP__

#include <db.hpp>

#include <sensor.h>

//
// These classes serialise the raw data returned from sensor listeners into a format
// suitable for insertion into the SQLite database, and write them there.
//
class SensorDataWriter
{
public:
	SensorDataWriter(DB &write_db);
	virtual void write(sensor_type_e sensor_type, unsigned long long int timestamp, float *data, int num_vals) = 0;
protected:
	DB &db;
};

//
// SensorDataWriter for PPG - this merges the separate PPG streams (raw reflectance and computed
// heart-rate) into a single stream for insertion into the database.
//
class PPGDataWriter : public SensorDataWriter
{
public:
	PPGDataWriter(DB &db): SensorDataWriter(db), hr_value_present(false), ppg_green_value_present(false) {}
	void write(sensor_type_e sensor_type, unsigned long long int timestamp, float *data, int num_vals);
private:
	bool hr_value_present;
	bool ppg_green_value_present;
	int hr_value;
	int ppg_green_value;
};

// SensorDataWriter for accelerometer - this performs a basic DB write
class AccelerometerDataWriter : public SensorDataWriter
{
public:
	AccelerometerDataWriter(DB &db): SensorDataWriter(db) {}
	void write(sensor_type_e sensor_type, unsigned long long int timestamp, float *data, int num_vals);
};


#endif // !__SENSORDATAWRITER_HPP__
