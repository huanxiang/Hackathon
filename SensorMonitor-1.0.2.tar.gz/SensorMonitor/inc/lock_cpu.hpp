/*
 * lock_cpu.hpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __LOCK_CPU_HPP__
#define __LOCK_CPU_HPP__

//
// These functions allow the Tizen CPU lock to be held by the app.
//
// If the CPU lock is not held, many functions of Tizen background service apps can be
// disrupted by the Tizen wearable power managment functions, which generally assume
// 'interesting' behaviour only happens while the user is interacting with the watch
// face. This results in gaps in sensor data measurement.
//
bool lock_cpu();
bool unlock_cpu();


#endif // !__CPU_LOCK_HPP__
