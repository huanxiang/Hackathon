/*
 * permissions.hpp
 *
 *  Created on: May 29, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __PERMISSIONS_HPP__
#define __PERMISSIONS_HPP__

// Request all permissions required by this app from Tizen O/S
void request_app_permissions();

#endif // !__PERMISSIONS_HPP__
