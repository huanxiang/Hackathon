/*
 * logger.hpp
 *
 *  Created on: May 27, 2019
 *      Author: Jonathan Hay (j.hay@waracle.com)
 *
 *   This product is © F.Hoffmann La-Roche Ltd. and is available under an Apache 2.0 license.
 *   For more information, see https://www.apache.org/licenses/LICENSE-2.0.txt
 *
 */

#ifndef __LOG_H__
#define __LOG_H__

#include <mutex>
#include <linux/limits.h>

//
// This class logs system events to the DLog debugging system, and to a file stored locally on the wearable
//
class Logger
{
public:
	Logger();
	~Logger();

	static Logger & getInstance()
	{
		static Logger instance;
		return instance;
	}

	// Subsystem for the log line
	typedef enum _Module
	{
		CAPTURE,
		DB,
		IMU,
		LOG,
		PPG,
		STORAGE,
		SQL,
		SYSTEM,
	} Module;
	const char *module_to_str(Logger::Module &module);

	bool open();
	void close();
	void purge_old_logs();

	void log(Module module, char const *format, ...);

private:
	std::mutex mutex;

	char log_dir[PATH_MAX];
	FILE *log_file;
	bool file_open;
};

#endif // !__LOG_H__
